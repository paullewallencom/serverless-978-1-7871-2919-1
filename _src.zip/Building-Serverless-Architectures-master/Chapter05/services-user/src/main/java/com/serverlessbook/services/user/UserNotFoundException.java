package com.serverlessbook.services.user;

public class UserNotFoundException extends Exception {
    private static final long serialVersionUID = -3235669501483817417L;
}
