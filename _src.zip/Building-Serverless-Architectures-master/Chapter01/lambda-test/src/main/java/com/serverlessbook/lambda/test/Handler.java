package com.serverlessbook.lambda.test;

public class Handler {
}
